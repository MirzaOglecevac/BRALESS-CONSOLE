<?php
namespace Model\Contract;

interface HasId
{
    public function getId();
}

